using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LeaveManagementSoftware
{
    public partial class Employee_Application_Form : Form
    {
        public Employee_Application_Form()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }

      
        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            connection CN = new connection();
            CN.thisConnection.Open();

            OracleCommand thisCommand = CN.thisConnection.CreateCommand();


            thisCommand.CommandText = "select Employee_Id,Employee_Name,Designation from Employee_Database where Employee_Id= '" + textBox1.Text + "'";

            OracleDataReader thisReader = thisCommand.ExecuteReader();


            while (thisReader.Read())
            {

                try
                {
                    textBox2.Text = thisReader["Employee_Name"].ToString();
                    textBox3.Text = thisReader["Designation"].ToString();
                    CN.thisConnection.Close();
                }
                catch
                {
                    MessageBox.Show(e.ToString());
                }
            }

            CN.thisConnection.Close();

        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {
            //this
            try
            {
                connection CN = new connection();
                CN.thisConnection.Open();

                OracleCommand thisCommand = CN.thisConnection.CreateCommand();


                thisCommand.CommandText = "select Employee_Name,Designation from Employee_Database where Employee_Id= '" + textBox1.Text + "'AND Security_Id= '" + textBox4.Text + "'";

                OracleDataReader thisReader = thisCommand.ExecuteReader();


                while (thisReader.Read())
                {
                    try
                    {
                        textBox2.Text = thisReader["Employee_Name"].ToString();
                        textBox3.Text = thisReader["Designation"].ToString();
                        CN.thisConnection.Close();
                    }
                    catch
                    {
                        // MessageBox.Show(e.ToString());
                    }
                }


                CN.thisConnection.Close();
            }
            catch(Exception ex)
            {
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection sv = new connection();
            sv.thisConnection.Open();

            OracleCommand thisCommand = sv.thisConnection.CreateCommand();

            thisCommand.CommandText =
               "delete Employee_Application where Employee_Id= '" + textBox1.Text + "'";

            thisCommand.Connection = sv.thisConnection;
            thisCommand.CommandType = CommandType.Text;

            try
            {
                thisCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error");
            }

            //


            /////////////////////////////////////

            OracleDataAdapter thisAdapter = new OracleDataAdapter("SELECT * FROM Employee_Application", sv.thisConnection);

            OracleCommandBuilder thisBuilder = new OracleCommandBuilder(thisAdapter);

            DataSet thisDataSet = new DataSet();
            thisAdapter.Fill(thisDataSet, "Employee_Application");

            DataRow thisRow = thisDataSet.Tables["Employee_Application"].NewRow();
            try
            {
                thisRow["Employee_Id"] = textBox1.Text;
                thisRow["Employee_Name"] = textBox2.Text;
                thisRow["Designation"] = textBox3.Text;
                thisRow["ToDate"] = dateTimePicker2.Value.Date.ToString();
                thisRow["FromDate"] = dateTimePicker1.Value.Date.ToString();
                thisRow["LeaveStatus"] = comboBox2.Text;                          
                thisRow["Status_Approve_Or_Not"] = "no";

                thisDataSet.Tables["Employee_Application"].Rows.Add(thisRow);



                int a = thisAdapter.Update(thisDataSet, "Employee_Application");

                if (a == 1)
                    MessageBox.Show("Successful");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Fill up all fields");
            }
            sv.thisConnection.Close();

            Employee_Login ob = new Employee_Login();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Entry Employee Id Then Press Status");
                return;
            }

            connection CN = new connection();
            CN.thisConnection.Open();

            OracleCommand thisCommand = CN.thisConnection.CreateCommand();

            thisCommand.CommandText = "SELECT * FROM Employee_Application where  Employee_Id = '" + textBox1.Text + "'";

            //where " + cb_searchby.Text + " like'%" + textBox1.Text + "%'order by BookId");

            OracleDataReader thisReader = thisCommand.ExecuteReader();


            while (thisReader.Read())
            {

                string s = thisReader["Status_Approve_Or_Not"].ToString();

                if (s == "no") MessageBox.Show("Application not process yet");
                else if(s == "Accept") MessageBox.Show("Application Accepted");
                else if (s == "Reject") MessageBox.Show("Application Rejected");

                try
                {
                    // string filePath = thisReader["picture"].ToString();
                    // this.pb_profilepics.Image = Image.FromFile(filePath);
                }
                catch
                { MessageBox.Show("successfull"); }


            }


            CN.thisConnection.Close();
        }
    }
}
