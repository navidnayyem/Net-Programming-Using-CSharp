﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OracleClient;

namespace LeaveManagementSoftware
{
    class connection
    {
        public OracleConnection thisConnection = new OracleConnection("Data Source=XE;User ID=LeaveManagementSystem;Password=LeaveManagementSystem;");
 
    }
}
