﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace LeaveManagementSoftware
{
    public partial class Employee_Login : Form
    {
        public Employee_Login()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            connection CN = new connection();

            CN.thisConnection.Open();
            OracleCommand thisCommand = new OracleCommand();
            thisCommand.Connection = CN.thisConnection;
            thisCommand.CommandText = "SELECT * FROM Employee_Database WHERE Employee_Id='" + textBox1.Text + "' AND Security_Id='" + textBox2.Text + "'";
            OracleDataReader thisReader = thisCommand.ExecuteReader();

            if (thisReader.Read())
            //if (Convert.ToBoolean(thisReader.Read()))
            {

                Employee_Application_Form ob = new Employee_Application_Form();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("username or password incorrect");
            }
            //this.Close();
            CN.thisConnection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EmpRegister ob = new EmpRegister();
            ob.Show();
            this.Hide();
        }
    }
}
