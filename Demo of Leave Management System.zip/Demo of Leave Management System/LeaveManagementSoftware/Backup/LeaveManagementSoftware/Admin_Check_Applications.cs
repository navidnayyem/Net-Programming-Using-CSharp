﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LeaveManagementSoftware
{
    public partial class Admin_Check_Applications : Form
    {
        public Admin_Check_Applications()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }

        private void Admin_Check_Applications_Load(object sender, EventArgs e)
        {
            connection CN = new connection();
            try
            {

                CN.thisConnection.Open();

                SqlCommand thisCommand = new SqlCommand("select Employee_Id,Employee_Name,Designation,FromDate, ToDate, LeaveStatus from Employee_Application where Status_Approve_Or_Not  = 'no' order by Employee_Id");

                thisCommand.Connection = CN.thisConnection;
                thisCommand.CommandType = CommandType.Text;

                SqlDataReader thisReader = thisCommand.ExecuteReader();

                listView1.Items.Clear();

                while (thisReader.Read())
                {

                    ListViewItem lsvItem = new ListViewItem();
                    lsvItem.Text = thisReader["Employee_Id"].ToString();
                    lsvItem.SubItems.Add(thisReader["Employee_Name"].ToString());
                    lsvItem.SubItems.Add(thisReader["Designation"].ToString());
                    lsvItem.SubItems.Add(thisReader["FromDate"].ToString());
                    lsvItem.SubItems.Add(thisReader["ToDate"].ToString());
                    lsvItem.SubItems.Add(thisReader["LeaveStatus"].ToString());

                    listView1.Items.Add(lsvItem);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                CN.thisConnection.Close();
            }

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Do you really want to Accept??", "Confirmation", MessageBoxButtons.YesNo);

            if (res == DialogResult.Yes)
            {
                connection sv = new connection();
                sv.thisConnection.Open();
                SqlCommand thisCommand = sv.thisConnection.CreateCommand();

                thisCommand.CommandText = "update Employee_Application set Status_Approve_Or_Not = 'Accept' where Employee_Id = '" + textBox10.Text + "'";

                thisCommand.Connection = sv.thisConnection;
                thisCommand.CommandType = CommandType.Text;

                try
                {
                    thisCommand.ExecuteNonQuery();
                    //Admin_Login ob = new Admin_Login();
                    //ob.Show();
                    //this.Hide();

                }
                catch (Exception ex)
                {
                    // MessageBox.Show("Not Updated");
                }

                sv.thisConnection.Close();
                this.Close();
                Admin_Check_Applications ob = new Admin_Check_Applications();
                ob.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection CN = new connection();
            CN.thisConnection.Open();

            SqlCommand thisCommand = CN.thisConnection.CreateCommand();

            thisCommand.CommandText =
            "SELECT * FROM Employee_Application where  Employee_Id  ='" + textBox10.Text + "'";

            //where " + cb_searchby.Text + " like'%" + textBox1.Text + "%'order by BookId");

            SqlDataReader thisReader = thisCommand.ExecuteReader();


            while (thisReader.Read())
            {

                textBox1.Text = thisReader["Employee_Name"].ToString();
                textBox2.Text = thisReader["Designation"].ToString();
                textBox3.Text = thisReader["FromDate"].ToString();
                textBox4.Text = thisReader["ToDate"].ToString();
                try
                {
                    // string filePath = thisReader["picture"].ToString();
                    // this.pb_profilepics.Image = Image.FromFile(filePath);
                }
                catch
                { 
                    // MessageBox.Show("successfull"); 
                }


            }


            CN.thisConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Do you really want to Reject??", "Confirmation", MessageBoxButtons.YesNo);

            if (res == DialogResult.Yes)
            {
                connection sv = new connection();
                sv.thisConnection.Open();
                SqlCommand thisCommand = sv.thisConnection.CreateCommand();

                thisCommand.CommandText = "update Employee_Application set Status_Approve_Or_Not = 'Reject' where Employee_Id = '" + textBox10.Text + "'";

                thisCommand.Connection = sv.thisConnection;
                thisCommand.CommandType = CommandType.Text;

                try
                {
                    thisCommand.ExecuteNonQuery();
                    //Admin_Login ob = new Admin_Login();
                    //ob.Show();
                    //this.Hide();

                }
                catch (Exception ex)
                {
                    // MessageBox.Show("Not Updated");
                }

                sv.thisConnection.Close();
                this.Close();
                Admin_Check_Applications ob = new Admin_Check_Applications();
                ob.Show();
            }
        }
    }
}
