﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LeaveManagementSoftware
{
    public partial class EmpRegister : Form
    {
        public EmpRegister()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection sv = new connection();
            sv.thisConnection.Open();

            SqlDataAdapter thisAdapter = new SqlDataAdapter("SELECT * FROM Employee_Database", sv.thisConnection);

            SqlCommandBuilder thisBuilder = new SqlCommandBuilder(thisAdapter);

            DataSet thisDataSet = new DataSet();
            thisAdapter.Fill(thisDataSet, "Employee_Database");

            DataRow thisRow = thisDataSet.Tables["Employee_Database"].NewRow();
            try
            {

                thisRow["Employee_Id"] = textBox1.Text;
                thisRow["Security_Id"] = textBox2.Text;
                thisRow["Employee_Name"] = textBox3.Text;
                thisRow["Designation"] = textBox4.Text;

                thisDataSet.Tables["Employee_Database"].Rows.Add(thisRow);


                thisAdapter.Update(thisDataSet, "Employee_Database");
                MessageBox.Show("Submitted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            sv.thisConnection.Close();

            Employee_Login ob = new Employee_Login();
            ob.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Employee_Login ob = new Employee_Login();
            ob.Show();
            this.Hide();
        }
    }
}
