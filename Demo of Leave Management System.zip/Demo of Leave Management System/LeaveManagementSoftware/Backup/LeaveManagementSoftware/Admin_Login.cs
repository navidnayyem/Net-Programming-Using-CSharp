﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LeaveManagementSoftware
{
    public partial class Admin_Login : Form
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection CN = new connection();

            CN.thisConnection.Open();
            SqlCommand thisCommand = new SqlCommand();
            thisCommand.Connection = CN.thisConnection;
            thisCommand.CommandText = "SELECT * FROM Admin_Login WHERE Admin_Username='" + textBox1.Text + "' AND Admin_Password='" + textBox2.Text + "'";
            SqlDataReader thisReader = thisCommand.ExecuteReader();

            if (thisReader.Read())
            //if (Convert.ToBoolean(thisReader.Read()))
            {

                Admin_Check_Applications ob = new Admin_Check_Applications();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("username or password incorrect");
            }
            //this.Close();
            CN.thisConnection.Close(); 
        }
    }
}
