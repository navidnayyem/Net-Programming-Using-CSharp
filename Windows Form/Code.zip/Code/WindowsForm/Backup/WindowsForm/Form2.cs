﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsForm
{
    public partial class Form2 : Form
    {
        public Form2(string name, string id)
        {
            InitializeComponent();
            MessageBox.Show("Hi. Name:" + name + "\n Id=" + id);
            textBox1.Text = name;
            textBox2.Text = id;
        }
    }
}
