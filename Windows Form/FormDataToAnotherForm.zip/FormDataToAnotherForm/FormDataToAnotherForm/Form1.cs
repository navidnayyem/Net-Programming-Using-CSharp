﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormDataToAnotherForm
{
    public partial class Form1 : Form
    {
      public static string sendtext = "";
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int data1 = Int32.Parse(textBox1.Text);
            int data2 = Int32.Parse(textBox2.Text);
            Form2 ob = new Form2(this, data1, data2);
            ob.Show();
        }        
    }
}
