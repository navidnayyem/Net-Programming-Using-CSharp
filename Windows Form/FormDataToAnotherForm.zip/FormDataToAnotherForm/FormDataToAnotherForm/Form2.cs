﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormDataToAnotherForm
{
    public partial class Form2 : Form
    {
        Form1 Frm1;
        public Form2(Form1 F, int a, int b)
        {
            InitializeComponent();
            Frm1 = F;
            textBox1.Text = (a + b).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = Int32.Parse(textBox1.Text) + 5;
            Frm1.textBox3.Text = sum.ToString();
        }
    }
}
