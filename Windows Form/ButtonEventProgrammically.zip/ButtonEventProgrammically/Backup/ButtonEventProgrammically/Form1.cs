﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ButtonEventProgrammically
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Button1
            Button button1 = new Button();
            button1.Text = "Button 1";
            button1.Parent = this;
            button1.Location = new System.Drawing.Point(100, 100);
            // an EventHandler delegate is assigned to the button's Click and Mouse Enter event
            button1.Click += new EventHandler(button_OnClick);

            // Button2
            Button button2 = new Button();
            button2.Text = "Button 2";
            button2.Parent = this;
            button2.Location = new System.Drawing.Point(200, 100);
            // an EventHandler delegate is assigned to the button's Click and Mouse Enter event
            button2.MouseLeave += new EventHandler(button_MouseLeave);
        }

        // this method is called when the "button_OnClick" button is pressed
        public void button_OnClick(object sender, EventArgs ea)
        {
            MessageBox.Show("Button clicked Event");
        }

        // this method is called when the "button_MouseLeave" button is pressed
        public void button_MouseLeave(object sender, EventArgs ea)
        {
            MessageBox.Show("Button Mouse Leave Event!");
        }
    }
}
